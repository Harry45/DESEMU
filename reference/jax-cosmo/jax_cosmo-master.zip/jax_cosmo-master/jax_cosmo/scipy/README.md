# JAX Scipy modules

This module hosts some JAX ports of useful scipy functions still missing from
the main JAX repo.
