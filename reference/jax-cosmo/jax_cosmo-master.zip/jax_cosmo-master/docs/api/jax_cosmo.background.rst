jax\_cosmo.background module
============================

.. automodule:: jax_cosmo.background
   :members:
   :undoc-members:
   :show-inheritance:
