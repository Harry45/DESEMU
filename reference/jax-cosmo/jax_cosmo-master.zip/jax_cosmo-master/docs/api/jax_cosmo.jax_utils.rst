jax\_cosmo.jax\_utils module
============================

.. automodule:: jax_cosmo.jax_utils
   :members:
   :undoc-members:
   :show-inheritance:
