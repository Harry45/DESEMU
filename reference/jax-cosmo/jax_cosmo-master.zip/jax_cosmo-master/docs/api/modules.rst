jax_cosmo public API
====================

.. toctree::
   :maxdepth: 4

   jax_cosmo
   jax_cosmo.scipy
