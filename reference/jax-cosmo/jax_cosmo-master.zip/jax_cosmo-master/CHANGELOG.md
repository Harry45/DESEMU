# Change log

<!--
Remember to align the itemized text with the first line of an item within a list.

Categories for updates can be:
* Changes
* Bugs
* Breaking Changes
* Deprecations
-->

## jax-cosmo v0.1.0 (Feb 5th 2023)

- Changes:
  - Official v0.1.0 release of the code.

## jax-cosmo v0.1rc10 (Unreleased)

- Changes:
  - Transferred contributing information to CONTRIBUTING.md

## jax-cosmo v0.1rc9 (Jan 20th 2022)

- Changes:
  - Updated dark energy EOS computation for stability reasons
